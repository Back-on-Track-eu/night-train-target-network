"""
params.py
=========
Domain parameter dataclasses for the Night Train model.

These are the typed representations of rows from input_params.* DB tables.
Populated exclusively by DBDataLoader (adapters/data_loader_from_db.py).
Shared across models/route/, models/evaluation/, and models/energy/.

DB table → domain class mapping
--------------------------------
  input_params.sources              → ParamsSource
  input_params.classes              → ServiceClass
  input_params.operators            → Operator
  input_params.operator_class_costs → Operator.svc_stockings_eur_place (dict)
  input_params.coachtypes           → CoachType
  input_params.coachtype_classes    → CoachClassAssignment (on CoachType)
  input_params.compositions         → CompositionType
  input_params.composition_coaches  → CompositionType.coaches (dict by position)
  Composition                       → fully resolved operational object
                                      built from CompositionType
  input_params.infrastructure       → TrackInfrastructure
  input_params.infrastructure_defaults → DefaultTrackInfra
  input_params.stops                → StopInfrastructure
  input_params.stop_defaults        → DefaultStopInfra

Provenance
----------
  Field-level source and version provenance for TrackInfrastructure and
  StopInfrastructure values lives exclusively in each collection's
  param_versions (a ParamVersions instance) — not on the domain objects
  themselves.

  Field-level description provenance for TrackInfrastructure and
  StopInfrastructure both live separately, once per collection, on
  TrackInfraCollection.descriptions / StopInfraCollection.descriptions —
  a field's documentation is identical for every country/stop, so
  ParamVersions entries no longer carry a redundant copy of it per
  country-or-stop/field. Compositions (Operator, CoachType, etc.) still
  carry description on their ParamVersionEntry, per-field, since that
  endpoint hasn't been revisited yet.

  Composition carries no provenance — it is a derived object.

Default fallback
----------------
  TrackInfrastructure and StopInfrastructure are always fully resolved.
  DefaultTrackInfra and DefaultStopInfra (EU-average fallback values) are
  merged in by the loader at build time: per field, whenever a country's
  or stop's own value is NULL, and — for TrackInfrastructure only — as a
  complete synthesized row for any country in input_params.countries
  that has no track_infrastructures row at all. Callers never see a
  missing or partially-None entry.

Collections
-----------
  TrackInfraCollection    — keyed by country_code, fully resolved rows
  StopInfraCollection     — keyed by stop_id, fully resolved rows
"""

from __future__ import annotations

import math

import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# =============================================================================
# PARAMS SOURCE  (input_params.sources)
# =============================================================================


@dataclass
class ParamsSource:
    """
    One source document referenced by a parameter table row.

    Mirrors input_params.sources. Carried on parameter objects either as
    a list (row-level, for Operator/CompositionType) or as paired _src
    fields per parameter value (for TrackInfrastructure/StopInfrastructure).
    """

    source_id: int
    source_description: str
    source_url: Optional[str]  # URL to source document or dataset
    source_date: Optional[str]  # ISO date string (YYYY-MM-DD)


# =============================================================================
# MODEL VERSIONS
# =============================================================================


@dataclass
class ModelVersions:
    """
    Records which version of each model was used in a computation.

    Carried in RouteProvenance, returned alongside Route by route_factory
    (not stored on Trip). New models register themselves by adding a key —
    no structural change needed.

    Example:
        {
            "route_builder": "1.0.0",
            "energy_calc":   "1.0.0",
            "cost_rev_calc": "1.0.0",
            "demand_model":  "1.0.0",   # future
        }
    """

    versions: dict[str, str]

    def get(self, model_name: str) -> Optional[str]:
        """Return version string for a model, or None if not recorded."""
        return self.versions.get(model_name)

    def set(self, model_name: str, version: str) -> None:
        """Register a model version."""
        self.versions[model_name] = version


# =============================================================================
# PARAM VERSIONS
# =============================================================================


@dataclass
class ParamVersionEntry:
    """
    One captured parameter field — fully flat, directly jsonifiable.

    One entry per parameter field, keyed by "table_short:entity_id:field_name"
    in ParamVersions.entries, e.g.:
        "track_infra:DE:tac_eur_train_km"
        "stop_infra:osm:n3856100103:stop_charge_eur"
        "composition_type:STD-7.1:max_speed_kmh"
        "operator:STD:driver_costs_eur_h"
        "coach_type:type1:weight_gross_t"
    """

    value: object
    version: Optional[int] = field(default=None)
    """DB version number for versioned tables (track/stop infrastructure).
    None for unversioned catalog tables (compositions, operators, coach
    types, composition references) — those have no version to report,
    since a changed value means a new id, not a new version of this one."""
    source: Optional[ParamsSource] = field(default=None)
    description: Optional[str] = field(default=None)
    is_default: bool = field(default=False)
    # is_default=True means this value was resolved from a default row
    # because the country/stop-specific value was NULL in the database.
    # Always False for unversioned catalog tables — they have no default
    # fallback concept.


@dataclass
class ParamVersions:
    """
    Captures which version of each parameter row was used in a computation,
    together with full source provenance.

    Populated on the fly by the loader. Carried on the relevant collection
    (TrackInfraCollection.param_versions, StopInfraCollection.param_versions,
    CompositionCollection.param_versions) rather than returned
    separately.

    Keys follow the pattern "table_short:entity_id", e.g.:
        "track_infra:DE"            → TrackInfrastructure for Germany
        "stop_infra:osm:n3856100103"  → StopInfrastructure for Berlin Hbf
        "composition_type:STD-7.1"  → CompositionType STD-7.1
        "coach_type:WLABmz"         → CoachType WLABmz
        "operator:STD"              → Operator STD
    """

    entries: dict[str, ParamVersionEntry] = field(default_factory=dict)

    def add(
        self,
        key: str,
        value: object,
        version: Optional[int] = None,
        source: Optional[ParamsSource] = None,
        description: Optional[str] = None,
        is_default: bool = False,
    ) -> None:
        """Register one parameter field. Safe to call multiple times — last
        write wins. version=None for unversioned catalog tables — see
        ParamVersionEntry."""
        self.entries[key] = ParamVersionEntry(
            value=value,
            version=version,
            source=source,
            description=description,
            is_default=is_default,
        )

    def get(self, key: str) -> ParamVersionEntry | None:
        return self.entries.get(key)


# =============================================================================
# SERVICE CLASS  (input_params.service_classes)
# =============================================================================


@dataclass
class ServiceClass:
    """
    One entry from the global accommodation class taxonomy.

    input_params.classes — stable reference table, not versioned.
    class_main groups individual classes into top-level categories:
    Seat, Couchette, Sleeper, Capsule, Catering.

    Density retired as a data column (2026-07-22): densities are derived
    per composition and class_main from real section geometry — see
    CompositionType.density_by_class_main_*. Cost allocation uses the
    calibration model (views.build_class_main_shares), not density.
    share one compartment unit. Stored in DB on the classes table.
    """

    class_id: str  # e.g. "seat (reclining)", "couchette (6-berth)"
    class_main: str  # e.g. "Seat", "Couchette", "Sleeper"
    is_night_accommodation: bool = False
    """Whether this class makes the train count as carrying night
    accommodation for tariff purposes — see the column comment on
    input_params.service_classes.service_class_is_night_accommodation and
    models/infrastructure/tac/calc_tac.py's night-band widening."""


# =============================================================================
# OPERATOR  (input_params.operators + input_params.operator_class_costs)
# =============================================================================


# =============================================================================
# ROSTER EFFICIENCY (Dienstplanwirkungsgrad)
# =============================================================================
#
# Shared by Operator (the DB mirror) and Composition (the flattened object
# evaluation works with), both of which carry the same five roster fields.
# The maths lives here once; see docs/MODEL.md for the derivation.


def roster_efficiency(rates, role: str, basis_h: float, on_train_h: float) -> float:
    """Share of paid hours that is productive, for one trip.

    Paid hours exceed hours on the train: sign-on/off, positioning,
    away-base rest and reserve cover. A duty is capped by law and
    agreement — driving time for drivers (Directive 2005/47/EC: 8 h on a
    night shift), working time for onboard staff — so a long trip needs
    relief crews, and each relief adds a fixed unproductive allowance.
    Efficiency therefore steps down at every duty boundary and recovers
    gradually as that allowance amortises over a longer trip.

    rates      — any object carrying the five roster fields
    role       — "driver" (basis: driving time) or "crew" (basis: time on train)
    basis_h    — hours measured against the duty cap
    on_train_h — productive hours paid for on this trip

    Returns the reference efficiency when the trip fits a single duty.
    """
    if role == "driver":
        max_duty, eff_ref = rates.driver_max_duty_h, rates.driver_roster_eff_ref
    else:
        max_duty, eff_ref = rates.crew_max_duty_h, rates.crew_roster_eff_ref
    if on_train_h <= 0 or max_duty <= 0:
        return eff_ref
    # -1e-9 keeps a trip of exactly max_duty at one duty despite float
    # noise in the summed minute fields.
    duties = max(1, math.ceil(basis_h / max_duty - 1e-9))
    return eff_ref * on_train_h / (on_train_h + rates.relief_allowance_h * (duties - 1))


def driver_rate_eur_h(rates, driving_h: float, on_train_h: float) -> float:
    """Paid driver rate for a trip — raw wage over roster efficiency."""
    return rates.driver_costs_eur_h / roster_efficiency(
        rates, "driver", driving_h, on_train_h
    )


def crew_rate_eur_h(rates, on_train_h: float) -> float:
    """Paid attendant rate for a trip — raw wage over roster efficiency."""
    return rates.crew_costs_eur_h / roster_efficiency(
        rates, "crew", on_train_h, on_train_h
    )


@dataclass
class Operator:
    """
    Train operating company — bears operational costs.

    Populated by DBDataLoader from input_params.operators (one row) and
    input_params.operator_class_costs (one row per class). Not versioned —
    operator_id is a permanent natural key; a changed rate means a new
    operator_id, never editing this row in place. Deduplicated and shared
    across every CompositionType that references it (see
    CompositionCollection).
    Linked as an object on CompositionType.

    svc_stockings_eur_place: variable cost of onboard services and stockings
    per available place per trip, keyed by class_id.

    Source and description provenance is handled by
    CompositionCollection.param_versions, not stored on this object.
    """

    operator_id: str
    operator_name: str
    driver_costs_eur_h: float  # EUR per PRODUCTIVE driver hour (raw wage)
    crew_costs_eur_h: float  # EUR per PRODUCTIVE crew hour (raw wage)
    # Roster (Dienstplanwirkungsgrad) parameters — see roster_efficiency().
    driver_max_duty_h: float
    crew_max_duty_h: float
    driver_roster_eff_ref: float
    crew_roster_eff_ref: float
    relief_allowance_h: float
    ebit_margin_per: float
    financing_quota_per: float
    var_overhead_per: float
    fix_overhead_quota_per: float
    svc_stockings_eur_place: dict[str, float]  # keyed by class_id

    # locomotive — utilization-based full-service lease (capital, maintenance,
    # insurance bundled into the rate). Billed per hour the loco is coupled
    # to a working train, i.e. segment total_time_min (driving + dynamics + buffer).
    # Energy, TAC, and driver/crew costs are NOT included — billed separately.
    # The rate itself lives on input_params.operator_loco_costs, per operator
    # AND machine, and reaches the model as Composition.loco_lease_eur_h.

    def roster_efficiency(self, role: str, basis_h: float, on_train_h: float) -> float:
        return roster_efficiency(self, role, basis_h, on_train_h)

    def driver_rate_eur_h(self, driving_h: float, on_train_h: float) -> float:
        return driver_rate_eur_h(self, driving_h, on_train_h)

    def crew_rate_eur_h(self, on_train_h: float) -> float:
        return crew_rate_eur_h(self, on_train_h)


# =============================================================================
# LOCOMOTIVE TYPE  (input_params.loco_types)
# =============================================================================


@dataclass
class LocoType:
    """
    One locomotive type — the physical machine, independent of who runs it.

    Weight and speed are intrinsic and live here. The rental rate does not:
    it is a commercial term varying by operator, resolved through
    input_params.operator_loco_costs and carried on the Composition, the
    same way onboard service cost varies by operator over service classes.
    """

    loco_type_id: str
    description: str
    traction: str
    weight_t: float
    max_speed_kmh: int


# =============================================================================
# COACH TYPE  (input_params.coachtypes + input_params.coachtype_classes)
# =============================================================================


@dataclass
class CoachClassAssignment:
    """
    One accommodation class assignment within a coach type.

    Materialized from input_params.coachtype_classes joined with
    input_params.classes. One entry per class_id per CoachType.
    A coach type may carry zero, one, or multiple class assignments.

    """

    class_id: str  # FK → input_params.classes.class_id
    class_main: str  # denormalised from input_params.classes
    is_night_accommodation: bool  # denormalised from input_params.classes
    places: int  # number of places of this class in the coach
    # real section geometry (workbook 2026-07-22) — basis of the class
    # cost allocation and of derived densities; Σ section_length_m over a
    # coach's sections = coach length excl. service areas
    section_length_m: float
    section_weight_t: float
    section_crew_factor: float


@dataclass
class CoachType:
    """
    Blueprint for a single coach vehicle.

    Populated by DBDataLoader from input_params.coachtypes and
    input_params.coachtype_classes. Stored in CompositionType.coaches
    keyed by position. Not versioned — coachtype_id is a permanent
    natural key; a changed spec means a new coachtype_id, never editing
    this row in place. Deduplicated and shared across every
    CompositionType that references it (see CompositionCollection).

    crew_factor: fractional cabin crew assigned per trip
                 (e.g. 0.5 = one crew member covers two coaches of this type)

    Source and description provenance is handled by
    CompositionCollection.param_versions, not stored on this object.
    """

    coachtype_id: str
    weight_gross_t: float
    length_m: float
    length_wo_service_m: float
    weight_wo_service_t: float
    has_wifi: bool
    crew_factor: float
    bikes: int
    climatization: bool
    plugs: bool
    classes: dict[str, CoachClassAssignment]  # keyed by class_id
    remarks: Optional[str] = (
        None  # free-text description, e.g. "STD seat coach — 80 reclining seats"
    )

    def places(self, class_id: str) -> int:
        """Places of a given class in this coach, or 0 if not present."""
        assignment = self.classes.get(class_id)
        return assignment.places if assignment else 0

    def total_places(self) -> int:
        """Total places across all classes in this coach."""
        return sum(a.places for a in self.classes.values())

    def has_night_accommodation(self) -> bool:
        """Whether any section of this coach is night accommodation."""
        return any(a.is_night_accommodation for a in self.classes.values())


# =============================================================================
# COMPOSITION TYPE  (input_params.compositions + input_params.composition_coaches)
# =============================================================================


@dataclass
class CompositionType:
    """
    Generic composition blueprint — describes the physical makeup of a train.

    Populated by DBDataLoader from input_params.compositions and
    input_params.composition_coaches. Not versioned — composition_type_id
    is a permanent natural key; new settings mean a new composition_type_id,
    never editing this row in place.

    coaches: ordered coach slots keyed by position (1 = first coach behind loco).
    operator: the operating company for this composition type.
    driver_factor: number of drivers required per trip (e.g. 1 or 2).

    Source and description provenance is handled by
    CompositionCollection.param_versions, not stored on this object.
    """

    comp_id: str
    comp_description: str
    operator: Operator
    driver_factor: float
    max_speed_kmh: float
    hsr_allowed: bool
    material_strategy: (
        str  # 'new' | 'refurbished' — drives the parameter family and operator tier
    )
    locos: list[LocoType]  # in position order; see composition_type_locos
    zugchef_crew_factor: float  # attendant-equivalents (1.19 / 2.38)
    length_cost_prop: float  # X of the class cost allocation (1-X on weight)
    food_and_beverages: str | None  # catering concept (composition-level)
    coaches: dict[int, CoachType]  # keyed by position

    # vehicle-dependent minimum dwell times
    min_boarding_time_min: int
    min_alighting_time_min: int

    # composition-level cost params — locomotives are full-service leased
    # (see input_params.operator_loco_costs), not purchased
    purchase_coach_eur: float
    coach_avail_per: float
    coach_amort_years: int
    cleaning_services_eur_day: float
    coach_maint_eur_km: float

    # indicative comparison KPIs — seeded from the composition cost
    # calibration (calib/CALIBRATION.md): S41 reference route, 2032 prices,
    # operator-controllable scope. Comparison figures, not route
    # evaluations. None when the seed predates the calibration.
    indicative_cost_eur_train_km: Optional[float] = None
    indicative_cost_ct_place_km: Optional[float] = None

    # --- derived getters ---

    def total_weight_t(self) -> float:
        """Total gross weight of all coaches in tonnes."""
        return sum(c.weight_gross_t for c in self.coaches.values())

    @property
    def n_locos(self) -> int:
        """Derived from the assignment, never stored — a count and a list
        that can disagree is a class of bug worth designing out."""
        return len(self.locos)

    def total_gross_weight_t(self) -> float:
        """Coaches plus every locomotive — the gross weight the traction
        dynamics haul and the weight-dependent track access charge is
        levied on. total_weight_t() is coaches only, since locomotives are
        leased rather than part of the composition's own coach list."""
        return self.total_weight_t() + sum(loco.weight_t for loco in self.locos)

    def has_night_accommodation(self) -> bool:
        """Whether any coach carries a night-accommodation section — the
        condition behind the German whole-run night pricing (see
        calc_tac.py). A property of the train alone, no timetable needed."""
        return any(c.has_night_accommodation() for c in self.coaches.values())

    def total_length_m(self) -> float:
        """Total coach length in metres (locomotive excluded)."""
        return sum(c.length_m for c in self.coaches.values())

    def total_length_wo_service_m(self) -> float:
        """Composition length excluding service areas."""
        return sum(c.length_wo_service_m for c in self.coaches.values())

    def total_weight_wo_service_t(self) -> float:
        """Composition weight excluding service areas."""
        return sum(c.weight_wo_service_t for c in self.coaches.values())

    def total_places(self) -> int:
        """Total places across all coaches and classes."""
        return sum(a.places for c in self.coaches.values() for a in c.classes.values())

    def total_crew(self) -> float:
        """Σ coach crew factors + Zugchef factor (attendant-equivalents)."""
        return (
            sum(c.crew_factor for c in self.coaches.values()) + self.zugchef_crew_factor
        )

    def amenities(self) -> dict[str, bool]:
        """OR-aggregation over coaches: the composition offers an amenity
        if any coach does."""
        cs = list(self.coaches.values())
        return {
            "has_wifi": any(c.has_wifi for c in cs),
            "has_bikes": any(c.bikes > 0 for c in cs),
            "has_climatization": any(c.climatization for c in cs),
            "has_plugs": any(c.plugs for c in cs),
        }

    def density_by_class_main_length(self) -> dict[str, float]:
        """Metres of section per place, per class_main — derived from real
        section geometry (replaces the retired service_class_density)."""
        m: dict[str, float] = {}
        pl: dict[str, int] = {}
        for c in self.coaches.values():
            for a in c.classes.values():
                m[a.class_main] = m.get(a.class_main, 0.0) + a.section_length_m
                pl[a.class_main] = pl.get(a.class_main, 0) + a.places
        return {k: m[k] / pl[k] for k in m if pl.get(k)}

    def avg_density_length_m_per_place(self) -> float:
        """Average length density (m/place) on the FULL composition
        length — service areas included, since every passenger uses them
        (workbook columns AL/AM). Note: per-class densities use section
        geometry (wo_service space); the composition average deliberately
        includes the shared areas."""
        return self.total_length_m() / self.total_places()

    def avg_density_weight_t_per_place(self) -> float:
        """Average weight density (t/place) on the full weight — service
        areas included (workbook AM)."""
        return self.total_weight_t() / self.total_places()

    def density_by_class_main_weight(self) -> dict[str, float]:
        """Tonnes of section per place, per class_main."""
        t: dict[str, float] = {}
        pl: dict[str, int] = {}
        for c in self.coaches.values():
            for a in c.classes.values():
                t[a.class_main] = t.get(a.class_main, 0.0) + a.section_weight_t
                pl[a.class_main] = pl.get(a.class_main, 0) + a.places
        return {k: t[k] / pl[k] for k in t if pl.get(k)}

    def places_by_class(self) -> dict[str, int]:
        """Total places per class_id across all coaches."""
        result: dict[str, int] = {}
        for coach in self.coaches.values():
            for class_id, a in coach.classes.items():
                result[class_id] = result.get(class_id, 0) + a.places
        return result

    def places_by_main_class(self) -> dict[str, int]:
        """Total places per class_main across all coaches."""
        result: dict[str, int] = {}
        for coach in self.coaches.values():
            for a in coach.classes.values():
                result[a.class_main] = result.get(a.class_main, 0) + a.places
        return result

    def weighted_avg_by_main_class(
        self, per_class_id_values: dict[str, float]
    ) -> dict[str, float]:
        """
        Places-weighted average of an arbitrary per-class_id value (e.g.
        Operator.svc_stockings_eur_place), aggregated up to class_main —
        same places-weighted-average shape as density_by_main_class()
        above, but over a caller-supplied value dict instead of the
        built-in per-class density.

        Model approach (David, 2026-07-06): classes within one class_main
        are assumed to be served at the same cost factor, so the
        class_main-level figure is simply the places-weighted average of
        the underlying class_id rates actually present in this
        composition's coach mix — not a max, not an unweighted average.

        weighted[class_main] = sum(places_i * value_i) / sum(places_i),
        for every class_id in that class_main group present in this
        composition. A class_id missing from per_class_id_values
        contributes 0.0 for its places (same fallback as the .get(...) call
        sites in models/evaluation/calc.py).
        """
        weighted: dict[str, float] = {}
        totals: dict[str, int] = {}
        for coach in self.coaches.values():
            for class_id, a in coach.classes.items():
                value = per_class_id_values.get(class_id, 0.0)
                weighted[a.class_main] = (
                    weighted.get(a.class_main, 0.0) + a.places * value
                )
                totals[a.class_main] = totals.get(a.class_main, 0) + a.places
        return {cm: weighted[cm] / totals[cm] for cm in weighted if totals[cm] > 0}


# =============================================================================
# COMPOSITION  (fully resolved operational object)
# =============================================================================


@dataclass
class Composition:
    """
    Fully resolved operational composition for a specific trip.

    Built from CompositionType at load time via Composition.from_type().
    All parameters are flat — no lazy loading, no optional fields.
    Stored on Trip.

    No provenance — Composition is a derived object; provenance lives on
    CompositionType, Operator, and CoachType it was built from.
    """

    # identity
    comp_id: str
    comp_description: str
    operator_id: str
    operator_name: str

    material_strategy: str
    locos: list[LocoType]  # in position order
    loco_lease_eur_h: dict[str, float]  # loco_type_id -> €/h for THIS operator
    zugchef_crew_factor: float
    length_cost_prop: float
    food_and_beverages: str | None

    # routing
    driver_factor: float
    max_speed_kmh: float
    hsr_allowed: bool
    min_boarding_time_min: int
    min_alighting_time_min: int

    # general train properties (derived from coaches)
    total_weight_t: float  # coaches only — total_gross_weight_t adds the locos
    total_length_m: float
    total_length_wo_service_m: float
    total_weight_wo_service_t: float
    # places-weighted average densities (workbook AL/AM analog)
    avg_density_length_m_per_place: float
    avg_density_weight_t_per_place: float
    total_crew: float

    # capacity (derived from coaches) — keyed by class_main (Seat, Couchette,
    # Sleeper, Capsule, Catering), not class_id. See Composition.from_type():
    # aggregated from CompositionType.places_by_main_class() /
    # density_by_main_class() — classes within one class_main are modelled
    # as served at the same cost factor (David, 2026-07-06), so there is no
    # need for OD pairs or cost lookups to go any more granular than this.
    places_by_class: dict[str, int]  # keyed by class_main
    # derived per-class densities from real section geometry (m/place and
    # t/place) — replace the retired service_class_density
    density_by_class_main_length: dict[str, float]
    density_by_class_main_weight: dict[str, float]

    # equipment (derived from coaches) — True if ANY coach in the composition has it
    has_wifi: bool
    has_bikes: bool
    has_climatization: bool
    has_plugs: bool

    # raw coach breakdown — the one non-aggregated field on this otherwise
    # flat object, kept so API consumers can list individual coaches
    # (id + remarks) without a second lookup. Keyed by position.
    coaches: dict[int, CoachType]

    # operator cost — driver/crew rates are RAW productive-hour wages;
    # evaluation divides them by the per-trip roster efficiency computed
    # from the five roster fields below.
    driver_costs_eur_h: float
    crew_costs_eur_h: float
    driver_max_duty_h: float
    crew_max_duty_h: float
    driver_roster_eff_ref: float
    crew_roster_eff_ref: float
    relief_allowance_h: float
    ebit_margin_per: float
    financing_quota_per: float
    var_overhead_per: float
    fix_overhead_quota_per: float
    svc_stockings_eur_place: dict[
        str, float
    ]  # keyed by class_main (weighted_avg_by_main_class()) — Operator's own copy above stays class_id-keyed
    # composition cost — locomotives are full-service leased, not purchased
    purchase_coach_eur: float
    coach_avail_per: float
    coach_amort_years: int
    cleaning_services_eur_day: float
    coach_maint_eur_km: float

    # indicative KPIs — seeded calibration values read from
    # composition_types columns (see IndicativeFigures). None if no
    indicative: Optional["IndicativeFigures"] = field(default=None)

    @property
    def n_locos(self) -> int:
        return len(self.locos)

    @property
    def total_gross_weight_t(self) -> float:
        """Coaches plus every locomotive — the gross weight the traction
        dynamics haul and the weight-dependent track access charge is
        levied on. total_weight_t is coaches only: locomotives are leased,
        not part of the composition's coach list."""
        return self.total_weight_t + sum(loco.weight_t for loco in self.locos)

    @property
    def loco_lease_total_eur_h(self) -> float:
        """Rate for the whole consist per locomotive-hour — the sum over
        the machines actually assigned, at this operator's rate for each.
        Replaces the old n_locos x one-rate product, which could only ever
        price identical machines."""
        return sum(self.loco_lease_eur_h[loco.loco_type_id] for loco in self.locos)

    @property
    def has_night_accommodation(self) -> bool:
        """Whether any coach carries a couchette, sleeper or capsule
        section. Germany prices a train that does at its night rate over
        the whole German run — see calc_tac.py."""
        return any(c.has_night_accommodation() for c in self.coaches.values())

    def driver_rate_eur_h(self, driving_h: float, on_train_h: float) -> float:
        """Paid driver rate for a trip — raw wage over roster efficiency."""
        return driver_rate_eur_h(self, driving_h, on_train_h)

    def crew_rate_eur_h(self, on_train_h: float) -> float:
        """Paid attendant rate for a trip — raw wage over roster efficiency."""
        return crew_rate_eur_h(self, on_train_h)

    @classmethod
    def from_type(
        cls, comp_type: CompositionType, loco_lease_eur_h: dict[str, float]
    ) -> "Composition":
        """
        Construct a fully resolved Composition from its CompositionType.
        Called exclusively by DBDataLoader.build_all_compositions().

        places_by_class / density_by_class_main_* / svc_stockings_eur_place are all
        aggregated up to class_main here (2026-07-06) — see the field
        comments above and CompositionType.places_by_main_class() /
        density_by_main_class() / weighted_avg_by_main_class(). Previously
        these were class_id-keyed; ODPair.class_main was always documented
        as a top-level category (see ODPair's own docstring) but in
        practice callers had to pass class_id strings to get a non-zero
        cost/density lookup in models/evaluation/calc.py. This makes the
        code match that original intent instead of the other way around.
        """
        return cls(
            comp_id=comp_type.comp_id,
            comp_description=comp_type.comp_description,
            operator_id=comp_type.operator.operator_id,
            operator_name=comp_type.operator.operator_name,
            material_strategy=comp_type.material_strategy,
            locos=comp_type.locos,
            loco_lease_eur_h=loco_lease_eur_h,
            zugchef_crew_factor=comp_type.zugchef_crew_factor,
            length_cost_prop=comp_type.length_cost_prop,
            food_and_beverages=comp_type.food_and_beverages,
            driver_factor=comp_type.driver_factor,
            max_speed_kmh=comp_type.max_speed_kmh,
            hsr_allowed=comp_type.hsr_allowed,
            min_boarding_time_min=comp_type.min_boarding_time_min,
            min_alighting_time_min=comp_type.min_alighting_time_min,
            total_weight_t=comp_type.total_weight_t(),
            total_length_m=comp_type.total_length_m(),
            total_length_wo_service_m=comp_type.total_length_wo_service_m(),
            total_weight_wo_service_t=comp_type.total_weight_wo_service_t(),
            avg_density_length_m_per_place=comp_type.avg_density_length_m_per_place(),
            avg_density_weight_t_per_place=comp_type.avg_density_weight_t_per_place(),
            total_crew=comp_type.total_crew(),
            places_by_class=comp_type.places_by_main_class(),
            density_by_class_main_length=comp_type.density_by_class_main_length(),
            density_by_class_main_weight=comp_type.density_by_class_main_weight(),
            has_wifi=comp_type.amenities()["has_wifi"],
            has_bikes=any(c.bikes > 0 for c in comp_type.coaches.values()),
            has_climatization=any(c.climatization for c in comp_type.coaches.values()),
            has_plugs=any(c.plugs for c in comp_type.coaches.values()),
            coaches=dict(comp_type.coaches),
            driver_costs_eur_h=comp_type.operator.driver_costs_eur_h,
            crew_costs_eur_h=comp_type.operator.crew_costs_eur_h,
            driver_max_duty_h=comp_type.operator.driver_max_duty_h,
            crew_max_duty_h=comp_type.operator.crew_max_duty_h,
            driver_roster_eff_ref=comp_type.operator.driver_roster_eff_ref,
            crew_roster_eff_ref=comp_type.operator.crew_roster_eff_ref,
            relief_allowance_h=comp_type.operator.relief_allowance_h,
            ebit_margin_per=comp_type.operator.ebit_margin_per,
            financing_quota_per=comp_type.operator.financing_quota_per,
            var_overhead_per=comp_type.operator.var_overhead_per,
            fix_overhead_quota_per=comp_type.operator.fix_overhead_quota_per,
            svc_stockings_eur_place=comp_type.weighted_avg_by_main_class(
                comp_type.operator.svc_stockings_eur_place
            ),
            purchase_coach_eur=comp_type.purchase_coach_eur,
            coach_avail_per=comp_type.coach_avail_per,
            coach_amort_years=comp_type.coach_amort_years,
            cleaning_services_eur_day=comp_type.cleaning_services_eur_day,
            coach_maint_eur_km=comp_type.coach_maint_eur_km,
        )


@dataclass
class CompositionCollection:
    """
    Dict-backed collection of Composition (the derived, flat operational
    object — see Composition's docstring) keyed by comp_id. Built eagerly
    and once by DBDataLoader.build_all_compositions().

    Not versioned/scenario-scoped: composition_types, operators, and
    coach_types are all unversioned catalogs (see their own docstrings) —
    a changed value means seeding a new id, never editing a row in place.
    build_all_compositions() still accepts a scenario_id, but only to
    resolve the TrackInfraCollection/StopInfraCollection used to compute
    each composition's indicative KPIs (Composition.indicative) — it has
    no bearing on composition, operator, or coach type field values
    themselves.

    Operator and CoachType instances are deduplicated at load time: every
    CompositionType (and therefore every Composition built from one) that
    references the same operator_id/coachtype_id shares the same object,
    loaded once rather than rebuilt per composition.

    param_versions carries one ParamVersionEntry per field across five
    prefixes: "composition_type:*", "operator:*", "operator_class_cost:*",
    "coach_type:*", "composition_reference:*" — provenance for the
    CompositionType blueprints these Compositions were derived from, not
    for Composition's own (already-flattened, unsourced) fields. Every
    entry's version is None (see ParamVersionEntry) since none of these
    tables are versioned. Per-entry `description` is deliberately left
    unset — see `descriptions` below.

    descriptions mirrors the ACTUAL response structure built by
    api/helpers/params_serialize.py's composition_collection_to_dict() —
    grouped as "compositions" (with "routing"/"staff"/
    "capacity"/"equipment"/"coaches"/"fixed_costs"/"variable_km"
    sub-sections, matching that function's per-composition dict exactly),
    "operators", and "indicative" (with "kpis"/"reference" sub-sections).
    Deliberately NOT grouped by source table (composition_types/
    — several DB columns (e.g. weight_gross_t, crew_factor, bikes on
    coach_types) are never exposed per-coach in the response at all, only
    as composition-level sums/booleans, so a table-shaped descriptions
    block would misrepresent what's actually returned. Built once in
    build_all_compositions() rather than duplicated per entity/field on
    param_versions — mirrors StopInfraCollection.descriptions /
    TrackInfraCollection.descriptions in spirit, though the shape here is
    response-section-keyed rather than {"table":..., "fields": {...}}
    since compositions span multiple source tables per section.
    """

    _data: dict[str, Composition]
    param_versions: ParamVersions
    descriptions: dict[str, dict]

    def __init__(
        self,
        data: dict[str, Composition],
        param_versions: ParamVersions,
        descriptions: dict[str, dict],
    ) -> None:
        self._data = data
        self.param_versions = param_versions
        self.descriptions = descriptions

    def get(self, comp_id: str) -> Optional[Composition]:
        return self._data.get(comp_id)

    def all(self) -> dict[str, Composition]:
        return self._data

    def __len__(self) -> int:
        return len(self._data)


# =============================================================================
# =============================================================================


@dataclass
class IndicativeFigures:
    """
    Indicative cost KPIs for a composition — seeded values from the
    composition cost calibration (backend/models/compositions/calib/
    CALIBRATION.md), read from composition_types columns by
    DBDataLoader.build_all_compositions(). Basis: S41 reference route
    (1,000 km, 14.5 h trip, 350 operating days, 2 trainsets), 2032
    prices, operator-controllable scope (no infrastructure access,
    energy, variable overhead or EBIT). Comparison figures between
    compositions — not route evaluations (models/evaluation/calc.py
    computes those for concrete routes).

    The basis (S41 reference route, 2032 prices, operator-controllable
    scope) is documented in the composition_types column comments —
    exposed via the API descriptions block — and derived in full in
    calib/CALIBRATION.md (the umbrella source).
    """

    cost_eur_per_train_km: float
    cost_ct_per_place_km: float


@dataclass
class DefaultTrackInfra:
    """
    EU-average fallback values for TrackInfrastructure fields.

    Populated by DBDataLoader from input_params.infrastructure_defaults.
    Used by DBDataLoader.build_all_tracks() to fill None fields on a
    country row, and to synthesize a complete row for any country in
    input_params.countries that has no track_infrastructures row at all.

    Each value has a paired _src field for provenance.
    """

    tac_eur_train_km: float
    tac_src: Optional[ParamsSource]

    parking_eur_day: float  # €/operating-day per parking event
    parking_src: Optional[ParamsSource]

    shunting_eur_event: float  # €/event per shunting movement
    shunting_src: Optional[ParamsSource]

    energy_price_eur_kwh: float
    energy_price_src: Optional[ParamsSource]

    terrain_score: float
    terrain_category: str
    terrain_src: Optional[ParamsSource]

    hsr_allowed: bool
    hsr_src: Optional[ParamsSource]

    min_boarding_time_min: int
    min_boarding_src: Optional[ParamsSource]

    min_alighting_time_min: int
    min_alighting_src: Optional[ParamsSource]

    buffer_quota_per: float
    buffer_src: Optional[ParamsSource]

    # --- track access charge components (models/infrastructure/tac/calc_tac.py)
    # All EUR at the 2032 evaluation year — the calibration notebook does
    # both conversions once, before seeding. A None here is a documented
    # tariff fact ("not levied"), never a gap: the loader substitutes this
    # whole group only when no rate term at all is present, so a lone None
    # survives resolution intact. Provenance for the group is track_tac_src,
    # shared by every component below (see TAC_COMPONENT_FIELD_NAMES).
    tac_b_day: Optional[float]  # €/train-km
    tac_b_night: Optional[float]  # €/train-km, on the night-band share
    tac_gamma: Optional[float]  # €/gross-tonne-km, whole consist
    tac_seat_km: Optional[float]  # €/seat-km (ES corridor surcharge)
    tac_per_stop: Optional[float]  # €/stop (CH Haltezuschlag)
    tac_revenue_share: Optional[float]  # fraction of attributable revenue
    tac_fixed_per_train_km: Optional[float]  # €/train-km (LU path admin)
    tac_peak_multiplier: Optional[float]  # scales the day rate in peak
    tac_congestion_surcharge_eur_km: Optional[float]  # flat €/train-km in peak
    tac_night_mode: str  # 'none' | 'time_band'
    tac_night_band_start_min: Optional[int]  # minute of day, may wrap midnight
    tac_night_band_end_min: Optional[int]
    tac_night_full_if_accommodation: bool  # DE whole-run night widening
    tac_peak_band1_start_min: Optional[int]
    tac_peak_band1_end_min: Optional[int]
    tac_peak_band2_start_min: Optional[int]
    tac_peak_band2_end_min: Optional[int]
    tac_peak_weekdays_only: bool

    # --- traction energy price terms
    #     (models/infrastructure/energy_pricing/calc_energy_price.py)
    # EUR at the 2032 evaluation year, converted once in the calibration
    # notebook. None is a tariff fact, never a gap, and — unlike the TAC
    # group — never substituted from the defaults row: no night price means
    # one rate around the clock, no catenary term means the country levies
    # no separate supply-equipment charge. Only the day rate above
    # (energy_price_eur_kwh) resolves against the default. Provenance for
    # the group is energy_price_src, shared with the day rate.
    energy_price_night_eur_kwh: Optional[float]  # €/kWh inside the band
    energy_night_band_start_min: Optional[int]  # minute of day, may wrap
    energy_night_band_end_min: Optional[int]
    energy_catenary_eur_train_km: Optional[float]  # €/train-km
    energy_catenary_eur_gross_tonne_km: Optional[float]  # €/gross-tonne-km

    # --- service facility terms
    #     (models/infrastructure/facility/calc_facility.py)
    # EUR at the 2032 evaluation year. Unlike the energy group these DO resolve
    # against the defaults row — as one group, keyed on parking_basis: every
    # country that stables a train charges something, or has been documented
    # not to, in which case its basis reads 'none'. Only the rate column
    # matching the basis carries a value. Provenance for the group is
    # parking_src, shared with the shunting figure it is calibrated alongside.
    parking_basis: Optional[str]  # per_metre_day | per_hour | per_event | none
    parking_eur_metre_day: Optional[float]
    parking_eur_hour: Optional[float]
    parking_eur_event: Optional[float]
    parking_free_hours: Optional[float]
    parking_hotel_power_eur_hour: Optional[float]

    def source_for(self, field_name: str) -> Optional[ParamsSource]:
        """
        Return this default row's source for a given TrackInfrastructure
        field name — handles the field → _src attribute mapping (most
        fields have their own, but terrain_score and terrain_category
        share terrain_src) once, here, instead of duplicated wherever
        DefaultTrackInfra values are consumed (build_all_tracks() and
        api/helpers/params_serialize.py).
        """
        return getattr(self, _TRACK_DEFAULT_SRC_ATTRS[field_name])


# =============================================================================
# TRACK INFRASTRUCTURE  (input_params.infrastructure)
# =============================================================================

TRACK_INFRA_FIELD_NAMES = (
    "tac_eur_train_km",
    "parking_eur_day",
    "shunting_eur_event",
    "energy_price_eur_kwh",
    "terrain_score",
    "terrain_category",
    "hsr_allowed",
    "min_boarding_time_min",
    "min_alighting_time_min",
    "buffer_quota_per",
)
"""Canonical value-field names on TrackInfrastructure (excludes country_code
and field_is_default). Shared by DBDataLoader for both per-field is_default
tracking on a real row and marking all of them True when synthesizing a
whole missing country's row — single source of truth so the two never
drift apart."""

TAC_COMPONENT_FIELD_NAMES = (
    "tac_b_day",
    "tac_b_night",
    "tac_gamma",
    "tac_seat_km",
    "tac_per_stop",
    "tac_revenue_share",
    "tac_fixed_per_train_km",
    "tac_peak_multiplier",
    "tac_congestion_surcharge_eur_km",
    "tac_night_mode",
    "tac_night_band_start_min",
    "tac_night_band_end_min",
    "tac_night_full_if_accommodation",
    "tac_peak_band1_start_min",
    "tac_peak_band1_end_min",
    "tac_peak_band2_start_min",
    "tac_peak_band2_end_min",
    "tac_peak_weekdays_only",
)
"""The calibrated TAC component fields, kept apart from
TRACK_INFRA_FIELD_NAMES above because they resolve as ONE GROUP rather
than field by field (see DBDataLoader._row_to_track): a country either
has its own tariff or is priced from the EU median, never a mixture. They
are registered in ParamVersions like any other field and share
track_tac_src for provenance."""

ENERGY_PRICE_FIELD_NAMES = (
    "energy_price_night_eur_kwh",
    "energy_night_band_start_min",
    "energy_night_band_end_min",
    "energy_catenary_eur_train_km",
    "energy_catenary_eur_gross_tonne_km",
)
"""The calibrated energy price terms beyond the day rate, kept apart from
TRACK_INFRA_FIELD_NAMES because they are never defaulted: a None here is
the documented tariff fact "not levied" (see DBDataLoader._row_to_track),
where a None in the ten legacy parameters is a gap the defaults row fills.
Registered in ParamVersions like any other field and sharing
energy_price_src with the day rate, which is the value they qualify."""

FACILITY_FIELD_NAMES = (
    "parking_basis",
    "parking_eur_metre_day",
    "parking_eur_hour",
    "parking_eur_event",
    "parking_free_hours",
    "parking_hotel_power_eur_hour",
)
"""The calibrated stabling terms, kept apart from TRACK_INFRA_FIELD_NAMES
because they resolve as ONE GROUP rather than field by field (see
DBDataLoader._row_to_track): a country prices in exactly one unit, so the two
unused rate columns are NULL by construction and defaulting them individually
would mix two countries' tariff structures. The trigger is parking_basis.
Shunting is not here — it stays the single per-event field
shunting_eur_event, which defaults like any other legacy parameter."""

TAC_RATE_FIELD_NAMES = ("tac_b_day", "tac_b_night", "tac_gamma")
"""The three distance-based rate terms whose joint absence triggers
group resolution. A country levying any one of them is calibrated; the
other components being None then means "not levied here"."""

_TRACK_DEFAULT_SRC_ATTRS = {
    "tac_eur_train_km": "tac_src",
    "parking_eur_day": "parking_src",
    "shunting_eur_event": "shunting_src",
    "energy_price_eur_kwh": "energy_price_src",
    "terrain_score": "terrain_src",
    "terrain_category": "terrain_src",
    "hsr_allowed": "hsr_src",
    "min_boarding_time_min": "min_boarding_src",
    "min_alighting_time_min": "min_alighting_src",
    "buffer_quota_per": "buffer_src",
    **{name: "tac_src" for name in TAC_COMPONENT_FIELD_NAMES},
    **{name: "energy_price_src" for name in ENERGY_PRICE_FIELD_NAMES},
    **{name: "parking_src" for name in FACILITY_FIELD_NAMES},
}
"""Maps each TRACK_INFRA_FIELD_NAMES / TAC_COMPONENT_FIELD_NAMES /
ENERGY_PRICE_FIELD_NAMES / FACILITY_FIELD_NAMES entry to
its source attribute on DefaultTrackInfra — see
DefaultTrackInfra.source_for(). The whole TAC component group shares
tac_src: a country's track access terms come from its network statement,
and where more than one document is involved the extras are named in the
row's change_log (the per-value record stays the calibration itself, see
models/infrastructure/tac/calib/TAC_CALIBRATION.md)."""


@dataclass
class TrackInfraDescriptions:
    """
    Static table/column documentation for input_params.track_infrastructures.

    Identical for every country — captured once per collection here rather
    than duplicated per country/field on ParamVersions (see
    TrackInfraCollection.descriptions). Mirrors StopInfraDescriptions.

    Populated by DBDataLoader.build_all_tracks() from Postgres COMMENT ON
    TABLE/COLUMN metadata — see DBDataLoader._load_table_comment() and
    ._load_column_comments(); the field → column name mapping (not a
    uniform "track_" + field_name prefix — see build_all_tracks()) lives
    there too, next to the analogous mapping for stops.
    """

    table: Optional[str]
    fields: dict[str, Optional[str]]
    # Keyed by TRACK_INFRA_FIELD_NAMES, already resolved to the right
    # underlying column comment — not the raw column names.


@dataclass
class TrackInfrastructure:
    """
    Per-country track infrastructure parameters.

    Populated by DBDataLoader.build_all_tracks(). All fields are fully
    resolved — the loader substitutes DefaultTrackInfra values for any
    None DB fields and logs a warning per substitution. Every country in
    input_params.countries is guaranteed to produce one of these — a
    country with no track_infrastructures row at all still gets one,
    synthesized entirely from DefaultTrackInfra (see build_all_tracks()).

    No _src fields here: source and version provenance for every field
    live exclusively on TrackInfraCollection.param_versions, not
    duplicated on this object.

    field_is_default: {field_name: was_this_field_defaulted} — kept ON
    this object (unlike source/version) because api/helpers/route_serialize.py
    reads it directly to build the "defaulted_fields" list in the
    route response (POST /api/proposal/calc, formerly POST /api/route/plan).
    Individual defaulted fields are expected and
    fine — that's what track_infrastructure_defaults is for.

    has_row: True if a real row exists in input_params.track_infrastructures
    for this country (regardless of how many of its fields are None and
    therefore defaulted), False if the country had no row at all and this
    object was synthesized entirely from DefaultTrackInfra. Since
    TrackInfraCollection.get() is never None for a legitimate country_code
    (see build_all_tracks()), "row missing" can no longer be signaled by a
    None return — has_row is that signal instead. This is what
    route_factory._check_country_coverage() checks: a country needs a row
    to be routable, but doesn't need every field populated.
    """

    country_code: str
    field_is_default: dict[str, bool]
    """{field_name: was_this_field_defaulted} — see class docstring."""
    has_row: bool
    """Whether a real input_params.track_infrastructures row exists for
    this country — see class docstring."""

    tac_eur_train_km: float
    parking_eur_day: float  # €/operating-day per parking event
    shunting_eur_event: float  # €/event per shunting movement
    energy_price_eur_kwh: float
    terrain_score: float
    terrain_category: str
    hsr_allowed: bool
    min_boarding_time_min: int
    min_alighting_time_min: int
    buffer_quota_per: float

    # --- track access charge components (models/infrastructure/tac/calc_tac.py)
    # All EUR at the 2032 evaluation year — the calibration notebook does
    # both conversions once, before seeding. A None here is a documented
    # tariff fact ("not levied"), never a gap: the loader substitutes this
    # whole group only when no rate term at all is present, so a lone None
    # survives resolution intact. Provenance for the group is track_tac_src,
    # shared by every component below (see TAC_COMPONENT_FIELD_NAMES).
    tac_b_day: Optional[float]  # €/train-km
    tac_b_night: Optional[float]  # €/train-km, on the night-band share
    tac_gamma: Optional[float]  # €/gross-tonne-km, whole consist
    tac_seat_km: Optional[float]  # €/seat-km (ES corridor surcharge)
    tac_per_stop: Optional[float]  # €/stop (CH Haltezuschlag)
    tac_revenue_share: Optional[float]  # fraction of attributable revenue
    tac_fixed_per_train_km: Optional[float]  # €/train-km (LU path admin)
    tac_peak_multiplier: Optional[float]  # scales the day rate in peak
    tac_congestion_surcharge_eur_km: Optional[float]  # flat €/train-km in peak
    tac_night_mode: str  # 'none' | 'time_band'
    tac_night_band_start_min: Optional[int]  # minute of day, may wrap midnight
    tac_night_band_end_min: Optional[int]
    tac_night_full_if_accommodation: bool  # DE whole-run night widening
    tac_peak_band1_start_min: Optional[int]
    tac_peak_band1_end_min: Optional[int]
    tac_peak_band2_start_min: Optional[int]
    tac_peak_band2_end_min: Optional[int]
    tac_peak_weekdays_only: bool

    # --- traction energy price terms
    #     (models/infrastructure/energy_pricing/calc_energy_price.py)
    # EUR at the 2032 evaluation year, converted once in the calibration
    # notebook. None is a tariff fact, never a gap, and — unlike the TAC
    # group — never substituted from the defaults row: no night price means
    # one rate around the clock, no catenary term means the country levies
    # no separate supply-equipment charge. Only the day rate above
    # (energy_price_eur_kwh) resolves against the default. Provenance for
    # the group is energy_price_src, shared with the day rate.
    energy_price_night_eur_kwh: Optional[float]  # €/kWh inside the band
    energy_night_band_start_min: Optional[int]  # minute of day, may wrap
    energy_night_band_end_min: Optional[int]
    energy_catenary_eur_train_km: Optional[float]  # €/train-km
    energy_catenary_eur_gross_tonne_km: Optional[float]  # €/gross-tonne-km

    # --- service facility terms
    #     (models/infrastructure/facility/calc_facility.py)
    # EUR at the 2032 evaluation year. Unlike the energy group these DO resolve
    # against the defaults row — as one group, keyed on parking_basis: every
    # country that stables a train charges something, or has been documented
    # not to, in which case its basis reads 'none'. Only the rate column
    # matching the basis carries a value. Provenance for the group is
    # parking_src, shared with the shunting figure it is calibrated alongside.
    parking_basis: Optional[str]  # per_metre_day | per_hour | per_event | none
    parking_eur_metre_day: Optional[float]
    parking_eur_hour: Optional[float]
    parking_eur_event: Optional[float]
    parking_free_hours: Optional[float]
    parking_hotel_power_eur_hour: Optional[float]


@dataclass
class TrackInfraCollection:
    """
    Dict-backed collection of TrackInfrastructure keyed by country_code.

    Built complete over every country in input_params.countries —
    DBDataLoader.build_all_tracks() synthesizes a full EU-average row for
    any country with no track_infrastructures row at all, at load time.
    So get(country_code) returns a real TrackInfrastructure for every
    legitimate country code; there is no lazy "return a default" method
    on this collection (there used to be a get_or_default() here — removed
    since defaulting for a whole missing country now happens once, in the
    loader, instead of being decided independently by every caller).

    param_versions carries one ParamVersionEntry per track field per
    country, keyed "track_infra:{country_code}:{field}" — including
    countries synthesized entirely from defaults. Per-entry `description`
    is deliberately left unset — see `descriptions` below, which is where
    field documentation actually lives for this collection.

    defaults carries the single EU-average fallback row (there is no
    per-country override table for tracks, unlike stops) this collection
    was resolved against — purely informational, never consulted during
    resolution itself (that already happened in build_all_tracks() before
    TrackInfraCollection was constructed).

    descriptions carries the static table/column documentation for
    track_infrastructures, captured once here rather than duplicated per
    country/field on param_versions (see TrackInfraDescriptions).

    Built once alongside _data by DBDataLoader.build_all_tracks() and
    never mutated afterwards.
    """

    _data: dict[str, TrackInfrastructure]
    param_versions: ParamVersions
    defaults: DefaultTrackInfra
    descriptions: TrackInfraDescriptions

    def __init__(
        self,
        data: dict[str, TrackInfrastructure],
        param_versions: ParamVersions,
        defaults: DefaultTrackInfra,
        descriptions: TrackInfraDescriptions,
    ) -> None:
        self._data = data
        self.param_versions = param_versions
        self.defaults = defaults
        self.descriptions = descriptions

    def get(self, country_code: str) -> Optional[TrackInfrastructure]:
        return self._data.get(country_code)

    def all(self) -> dict[str, TrackInfrastructure]:
        return self._data

    def __len__(self) -> int:
        return len(self._data)


# =============================================================================
# PASSAGE CHARGES  (input_params.passage_charges)
# =============================================================================

PASSAGE_FIELD_NAMES = ("fixed_eur", "per_passenger_eur")
"""Canonical value-field names on PassageCharge — shared by DBDataLoader
for ParamVersions registration, mirroring TRACK_INFRA_FIELD_NAMES."""


@dataclass
class PassageCharge:
    """
    One crossing charged per traverse rather than per kilometre — the
    Storebælt and Øresund fixed links, the Channel Tunnel (extensible to
    Fehmarnbelt in a 2032 scenario).

    Populated by DBDataLoader.build_all_passages(). A crossing is its own
    entity keyed by passage_id rather than a country attribute, because
    the charging party is the crossing's operator: Øresund is two rows
    over one polygon, each infrastructure manager billing its half.

    Geometry is deliberately NOT carried here. Polygon matching happens at
    routing time (rail_router.PassageIndex), so by the time evaluation
    runs a Segment already knows which crossings it owns.

    fixed_eur          per train traverse, one way
    per_passenger_eur  per carried passenger, one way (Channel Tunnel) —
                       evaluated against the segment's passenger load, so
                       this term follows demand rather than routing

    No _src fields: source and version provenance live on
    PassageChargeCollection.param_versions, mirroring TrackInfrastructure.
    """

    passage_id: str
    passage_name: str
    fixed_eur: float
    per_passenger_eur: float


@dataclass
class PassageChargeCollection:
    """
    Dict-backed collection of PassageCharge keyed by passage_id, built by
    DBDataLoader.build_all_passages() at a scenario's pinned version —
    passage_charges is the fifth scenario-versioned infrastructure table,
    under the same full-snapshot contract as the other four.

    get() returns None for an unknown passage_id. calc_tac.py logs and
    skips rather than failing there: a routing-time geometry match against
    a charge row dropped in a later version is a data inconsistency worth
    surfacing, not worth killing an evaluation over.
    """

    _data: dict[str, PassageCharge]
    param_versions: ParamVersions

    def __init__(
        self, data: dict[str, PassageCharge], param_versions: ParamVersions
    ) -> None:
        self._data = data
        self.param_versions = param_versions

    def get(self, passage_id: str) -> Optional[PassageCharge]:
        return self._data.get(passage_id)

    def all(self) -> dict[str, PassageCharge]:
        return self._data

    def __len__(self) -> int:
        return len(self._data)


# =============================================================================
# STOP INFRASTRUCTURE DEFAULTS  (input_params.stop_defaults)
# =============================================================================


@dataclass
class DefaultStopInfra:
    """
    EU-average fallback values for StopInfrastructure fields.

    Populated by DBDataLoader from input_params.stop_defaults.
    Used by DBDataLoader.build_all_stops() to fill a stop's None
    stop_charge_eur — see StopInfrastructure's docstring.
    """

    stop_charge_eur: float
    stop_charge_src: Optional[ParamsSource]


# =============================================================================
# STOP INFRASTRUCTURE DESCRIPTIONS  (pg_catalog COMMENT ON TABLE/COLUMN)
# =============================================================================


@dataclass
class StopInfraDescriptions:
    """
    Static table/column documentation for input_params.stop_infrastructures.

    Identical for every stop — unlike source/version/is_default, a field's
    description never varies row to row, so it is captured once per
    collection here rather than duplicated per stop/field on ParamVersions
    (see StopInfraCollection.descriptions).

    Populated by DBDataLoader.build_all_stops() from Postgres COMMENT ON
    TABLE/COLUMN metadata — see DBDataLoader._load_table_comment() and
    ._load_column_comments().
    """

    table: Optional[str]
    fields: dict[str, Optional[str]]
    # Keyed by the field names exposed in StopInfrastructure/the API
    # response ("lat", "lon", "stop_charge_eur") — already resolved to
    # the right underlying column comment, not the raw column names.


# =============================================================================
# STOP INFRASTRUCTURE  (input_params.stops)
# =============================================================================


@dataclass
class StopInfrastructure:
    """
    One stop — location and station access charge.

    Populated by DBDataLoader.build_all_stops(). All fields are fully
    resolved — the loader substitutes DefaultStopInfra.stop_charge_eur
    for any stop with no charge value and logs a warning.

    stop_charge_eur IS exposed in the /api/params/StopInfrastructures
    response (see api/params.py get_stop_infrastructures()), alongside
    its full provenance. It's also used internally by
    models/evaluation/calc.py.

    No _src fields here: source and version provenance for every field
    (lat, lon, stop_charge_eur — including which one, if any, was
    resolved from the default row) live exclusively on
    StopInfraCollection.param_versions, not duplicated on this object.
    """

    stop_id: str
    stop_name: str
    stop_country_code: str

    lat: float
    lon: float

    stop_charge_eur: float


@dataclass
class StopInfraCollection:
    """
    Dict-backed collection of StopInfrastructure keyed by stop_id.

    All rows are fully resolved by the loader — stop_charge_eur is never None.

    param_versions carries one ParamVersionEntry per stop field (lat, lon,
    stop_charge_eur — see build_all_stops()), keyed "stop_infra:{stop_id}:{field}".
    Per-entry `description` is deliberately left unset for stop fields —
    see `descriptions` below, which is where field documentation actually
    lives for this collection.

    defaults carries the raw EU-average fallback rows this collection was
    resolved against, keyed by country_code (None = the global fallback) —
    purely informational (e.g. for API responses that want to show what a
    stop with a NULL charge would have fallen back to), never consulted
    during resolution itself (that already happened in build_all_stops()
    before StopInfraCollection was constructed).

    descriptions carries the static table/column documentation for
    stop_infrastructures, captured once here rather than duplicated per
    stop/field on param_versions (see StopInfraDescriptions).

    Built once alongside _data by DBDataLoader.build_all_stops() and never
    mutated afterwards — this is now the single source of provenance for
    everything in this collection; callers no longer receive any of it as
    a separate return value.
    """

    _data: dict[str, StopInfrastructure]
    param_versions: ParamVersions
    defaults: dict[Optional[str], DefaultStopInfra]
    descriptions: StopInfraDescriptions

    def __init__(
        self,
        data: dict[str, StopInfrastructure],
        param_versions: ParamVersions,
        defaults: dict[Optional[str], DefaultStopInfra],
        descriptions: StopInfraDescriptions,
    ) -> None:
        self._data = data
        self.param_versions = param_versions
        self.defaults = defaults
        self.descriptions = descriptions

    def get(self, stop_id: str) -> Optional[StopInfrastructure]:
        return self._data.get(stop_id)

    def get_charge(self, stop_id: str) -> float:
        """
        Return stop_charge_eur for a stop.
        Raises KeyError if stop_id is not found — a missing stop is a data
        integrity failure since routing requires lat/lon from the same row.
        """
        row = self._data.get(stop_id)
        if row is None:
            raise KeyError(f"Stop '{stop_id}' not found in StopInfraCollection.")
        return row.stop_charge_eur

    def all(self) -> dict[str, StopInfrastructure]:
        return self._data

    def __len__(self) -> int:
        return len(self._data)


# =============================================================================
# OD PAIR  (persistent demand input — lives on Route)
# =============================================================================


@dataclass
class ODPair:
    """
    Demand for one origin-destination pair on one specific trip.

    Persistent domain object stored alongside the Route. Lives on Route
    (not Trip) so that Y-shaped routes can express demand correctly: a
    Berlin→Copenhagen OD pair that spans both the Berlin→Oslo and
    Berlin→Stockholm trips is represented as two ODPair objects, each
    referencing its own trip_id with its own places_sold.

    The demand split across trips for shared legs is a user input —
    the model does not derive it.

    class_main: top-level accommodation category from ServiceClass
    (e.g. "Seat", "Couchette", "Sleeper"). One ODPair per class per
    OD pair per trip — if a single OD pair carries both Couchette and
    Sleeper demand, that is two ODPair objects. Matches
    Composition.places_by_class / density_by_class_main_* / svc_stockings_eur_place
    (2026-07-06) — those are now aggregated up to class_main too, so there
    is no need (and no way) to target a more granular class_id here.

    places_sold: annual total tickets sold for this OD pair / class / trip.
    Operators think and plan in annual figures — per-trip demand is derived
    by dividing by operating_days_per_year from the relevant TripPair's
    Schedule.

    avg_price: average ticket price across all tickets sold for this
    OD pair, class, and trip. EUR.
    """

    origin_stop_id: str
    destination_stop_id: str
    class_main: str  # "Seat" | "Couchette" | "Sleeper" | "Capsule" | "Catering"
    trip_id: str  # references Trip.trip_id within the same Route
    places_sold: int  # annual tickets sold for this OD pair / class / trip
    avg_price: float  # EUR — average fare across all sold tickets


# =============================================================================
# SCENARIO  (scenario.scenarios)
# =============================================================================


@dataclass
class Scenario:
    """
    One row of scenario.scenarios — a container pinning one version of
    each versioned infrastructure table. See
    db/schema.py (scenario.scenarios) and db/README.md for the full versioning
    contract; summarized here for the fields this object carries:

    is_current_base: TRUE for exactly one row in the whole table — the
    live default scenario used whenever an API call omits scenario_id.

    is_current_scenario: TRUE for exactly one row per scenario_key — the
    head of that what-if lineage. Older versions of the same lineage
    carry the same scenario_key with is_current_scenario=False.

    Populated exclusively by DBDataLoader.list_all_scenarios(). Read-only
    — scenario rows are written directly in SQL/notebooks for now, not
    through the API.
    """

    scenario_id: int
    scenario_key: str
    scenario_name: str
    description: Optional[str]
    change_log: Optional[str]
    editor: Optional[str]
    created_at: str  # ISO datetime string
    is_current_base: bool
    is_current_scenario: bool
    track_infrastructures_version: int
    track_infrastructure_defaults_version: int
    stop_infrastructures_version: int
    stop_infrastructure_defaults_version: int
    passage_charges_version: int
